package com.varxyz.ncs.calc;

public class CalculatorTest {

	public static void main(String[] args) {
		
	}
}
