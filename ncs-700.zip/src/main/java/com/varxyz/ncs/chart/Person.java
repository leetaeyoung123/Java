package com.varxyz.ncs.chart;

public class Person {

}
