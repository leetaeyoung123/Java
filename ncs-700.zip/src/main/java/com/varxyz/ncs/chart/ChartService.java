package com.varxyz.ncs.chart;

import java.util.List;

public interface ChartService {
	public List<Person> person();
	
	public List<cigarettes> cigarettesType();
}
