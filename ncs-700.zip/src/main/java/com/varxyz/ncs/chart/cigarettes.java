package com.varxyz.ncs.chart;

public class cigarettes {

}
